package com.example.intent2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.intent2.R;
import com.example.intent2.SecondActivity;

public class MainActivity extends AppCompatActivity {

    private Button Btn;
    private EditText pass, email;

    private SharedPreferences Pref;
    private String PrefName = "MyPref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Btn = findViewById(R.id.BtnID);
        pass = findViewById(R.id.PassID);
        email = findViewById(R.id.EmailID);

        Pref = getSharedPreferences(PrefName,MODE_PRIVATE);

        if (Pref.contains("useremail")){
            Intent myIntent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(myIntent);
        }

        Toast.makeText(this, "", Toast.LENGTH_SHORT).show();

        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Email = email.getText().toString();
                String Pass = pass.getText().toString();

                Validate(Email, Pass);
            }
        });
    }


    public void Validate(String Email, String Pass){

        if(!Email.contains(("@"))){
            Toast.makeText(this, "Invalid Emial Entered!", Toast.LENGTH_SHORT).show();
            return;
        }
        if(Pass.length() < 8){
            Toast.makeText(this, "Invalid Password Entered!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Email.equals("admin@gmail.com") && Pass.equals("abc12345")){

            SharedPreferences.Editor edtPref = Pref.edit();
            edtPref.putString("useremail",Email);
            edtPref.commit();

            Intent myIntent = new Intent(MainActivity.this, SecondActivity.class);
            myIntent.putExtra("email",Email);
            startActivity(myIntent);
            finish();
        }


    }
}