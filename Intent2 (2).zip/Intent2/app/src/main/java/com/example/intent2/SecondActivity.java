package com.example.intent2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    private SharedPreferences Pref;
    private String PrefName = "MyPref";
    private Button BtnLogout;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private TextView Show;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Show = findViewById(R.id.textview);
        BtnLogout = findViewById(R.id.btnLogOut);

        Pref = getSharedPreferences(PrefName, MODE_PRIVATE);

        String Name = Pref.getString("useremail", "");

        Show.setText(Name);

        BtnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(SecondActivity.this, "", Toast.LENGTH_SHORT).show();


                AlertDialog.Builder build = new AlertDialog.Builder(SecondActivity.this);
                build.setTitle("LogOut")
                        .setMessage("Logout ?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                SharedPreferences.Editor edtPref = Pref.edit();
                                edtPref.remove("useremail");
                                edtPref.commit();

                                Intent go = new Intent(SecondActivity.this, MainActivity.class);
                                startActivity(go);

                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog alert = build.create();
                alert.show();
            }
        });

//        Intent Data = getIntent();
//        String UserEmail = Data.getStringExtra("email");
//        Show.setText(UserEmail);
    }
}